import React, { useEffect, useMemo, useState } from 'react';
import { AdminLayout } from './AdminLayout';
import { ResponsiveTable, Column } from './ResponsiveTable';
import { Card } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '../ui/dialog';
import { BarChart3, Activity, TrendingUp, Users } from 'lucide-react';
import {
  adminLogin,
  adminLogout,
  verifyAdminToken,
  getAdminWorkshopBookings,
  getAdminContactSubmissions,
  getAdminBrochureRequests,
  getAdminExerciseResponses,
  getAdminAssessments,
  getAdminNewsletterSubscribers,
  updateWorkshopBookingStatus,
} from '../../utils/supabaseApi';

type AdminSection = 'dashboard' | 'analytics' | 'leads' | 'profiles' | 'contact' | 'workshops' | 'brochures' | 'exercises' | 'assessments' | 'newsletter';

interface WorkshopBooking {
  id: string;
  first_name: string;
  last_name: string;
  email: string;
  phone?: string;
  company?: string;
  position?: string;
  team_size?: number;
  workshop_type: string;
  preferred_date?: string;
  preferred_time?: string;
  language: string;
  location_preference?: string;
  budget_range?: string;
  message?: string;
  status: 'draft' | 'pending' | 'confirmed' | 'cancelled';
  created_at: string;
}

export function AdminDashboard() {
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('admin_token'));
  const [me, setMe] = useState<{ email: string } | null>(null);
  const [error, setError] = useState<string>('');
  const [currentSection, setCurrentSection] = useState<AdminSection>('workshops');

  // Data state
  const [workshopBookings, setWorkshopBookings] = useState<any[]>([]);
  const [contactSubmissions, setContactSubmissions] = useState<any[]>([]);
  const [brochureRequests, setBrochureRequests] = useState<any[]>([]);
  const [exerciseResponses, setExerciseResponses] = useState<any[]>([]);
  const [assessments, setAssessments] = useState<any[]>([]);
  const [newsletterSubscribers, setNewsletterSubscribers] = useState<any[]>([]);

  // Loading
  const [workshopBookingsLoading, setWorkshopBookingsLoading] = useState(false);
  const [contactSubmissionsLoading, setContactSubmissionsLoading] = useState(false);
  const [brochureRequestsLoading, setBrochureRequestsLoading] = useState(false);
  const [exerciseResponsesLoading, setExerciseResponsesLoading] = useState(false);
  const [assessmentsLoading, setAssessmentsLoading] = useState(false);
  const [newsletterSubscribersLoading, setNewsletterSubscribersLoading] = useState(false);

  // Selection
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());
  const [selectAll, setSelectAll] = useState(false);

  // Dialog
  const [detailsDialogOpen, setDetailsDialogOpen] = useState(false);
  const [selectedEntry, setSelectedEntry] = useState<any>(null);

  // Auth
  const verify = async (tok: string) => {
    try {
      if (verifyAdminToken()) {
        setMe({ email: 'admin@aiworkshop.ch' });
        setError('');
        return true;
      } else {
        throw new Error('not authed');
      }
    } catch {
      setMe(null);
      setError('');
      return false;
    }
  };

  useEffect(() => {
    (async () => {
      if (token) {
        const ok = await verify(token);
        if (!ok) {
          localStorage.removeItem('admin_token');
          setToken(null);
        }
      }
    })();
  }, []);

  const onLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const email = formData.get('email') as string;
    const password = formData.get('password') as string;

    try {
      const response = await adminLogin(email, password);
      if (response.success && response.data) {
        setToken(response.data.token);
        setMe({ email: response.data.email });
        setError('');
      } else {
        throw new Error(response.error || 'Login failed');
      }
    } catch (err: any) {
      setError(err.message);
    }
  };

  const logout = () => {
    adminLogout();
    setToken(null);
    setMe(null);
  };

  // Loaders
  const loadWorkshopBookings = async () => {
    setWorkshopBookingsLoading(true);
    try {
      const response = await getAdminWorkshopBookings();
      if (response.success && response.data) {
        setWorkshopBookings(response.data.bookings || []);
      }
    } catch (err) {
      console.error('Failed to load workshop bookings:', err);
    } finally {
      setWorkshopBookingsLoading(false);
    }
  };

  const loadContactSubmissions = async () => {
    setContactSubmissionsLoading(true);
    try {
      const response = await getAdminContactSubmissions();
      if (response.success && response.data) {
        setContactSubmissions(response.data.submissions || []);
      }
    } catch (err) {
      console.error('Failed to load contact submissions:', err);
    } finally {
      setContactSubmissionsLoading(false);
    }
  };

  const loadBrochureRequests = async () => {
    setBrochureRequestsLoading(true);
    try {
      const response = await getAdminBrochureRequests();
      if (response.success && response.data) {
        setBrochureRequests(response.data.requests || []);
      }
    } catch (err) {
      console.error('Failed to load brochure requests:', err);
    } finally {
      setBrochureRequestsLoading(false);
    }
  };

  const loadExerciseResponses = async () => {
    setExerciseResponsesLoading(true);
    try {
      const response = await getAdminExerciseResponses();
      if (response.success && response.data) {
        setExerciseResponses(response.data.responses || []);
      }
    } catch (err) {
      console.error('Failed to load exercise responses:', err);
    } finally {
      setExerciseResponsesLoading(false);
    }
  };

  const loadAssessments = async () => {
    setAssessmentsLoading(true);
    try {
      const response = await getAdminAssessments();
      if (response.success && response.data) {
        setAssessments(response.data.assessments || []);
      }
    } catch (err) {
      console.error('Failed to load assessments:', err);
    } finally {
      setAssessmentsLoading(false);
    }
  };

  const loadNewsletterSubscribers = async () => {
    setNewsletterSubscribersLoading(true);
    try {
      const response = await getAdminNewsletterSubscribers();
      if (response.success && response.data) {
        setNewsletterSubscribers(response.data.subscribers || []);
      }
    } catch (err) {
      console.error('Failed to load newsletter subscribers:', err);
    } finally {
      setNewsletterSubscribersLoading(false);
    }
  };

  // Status update
  const handleStatusChange = async (id: string, status: 'pending' | 'confirmed' | 'cancelled' | 'draft') => {
    try {
      const response = await updateWorkshopBookingStatus(id, status);
      if (response.success) {
        setWorkshopBookings(prev =>
          prev.map(booking => (booking.id === id ? { ...booking, status } : booking))
        );
      }
    } catch (err) {
      console.error('Failed to update status:', err);
    }
  };

  // Selection helpers
  const handleSelectItem = (id: string, selected: boolean) => {
    setSelectedItems(prev => {
      const next = new Set(prev);
      if (selected) next.add(id); else next.delete(id);
      return next;
    });
  };
  const handleSelectAll = (selected: boolean) => {
    const source = currentSection === 'workshops' ? workshopBookings : [];
    setSelectedItems(selected ? new Set(source.map((x: any) => x.id)) : new Set());
    setSelectAll(selected);
  };

  const exportCsv = () => {
    // Let ResponsiveTable fallback export handle it when onExport is not provided.
    console.log('Export triggered');
  };

  const loadAll = () => {
    switch (currentSection) {
      case 'workshops':
        loadWorkshopBookings(); break;
      case 'contact':
        loadContactSubmissions(); break;
      case 'brochures':
        loadBrochureRequests(); break;
      case 'exercises':
        loadExerciseResponses(); break;
      case 'assessments':
        loadAssessments(); break;
      case 'newsletter':
        loadNewsletterSubscribers(); break;
      case 'leads':
      case 'profiles':
      case 'dashboard':
        loadWorkshopBookings();
        loadContactSubmissions();
        loadBrochureRequests();
        loadExerciseResponses();
        loadAssessments();
        loadNewsletterSubscribers();
        break;
    }
  };

  useEffect(() => { loadAll(); }, [currentSection]);

  if (!token || !me) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="max-w-sm w-full">
          <div className="text-center mb-12">
            <h1 className="text-3xl font-light text-black tracking-wide">AI Workshop</h1>
            <p className="text-gray-500 mt-2 font-light">Admin Dashboard</p>
          </div>
          {error && (
            <div className="bg-gray-100 border border-gray-200 text-gray-700 px-4 py-3 rounded-lg mb-6 text-sm">
              {error}
            </div>
          )}
          <form onSubmit={onLogin} className="space-y-6">
            <div>
              <input type="email" id="email" name="email" required className="w-full px-0 py-3 border-0 border-b border-gray-300 bg-transparent focus:outline-none focus:border-black text-black placeholder-gray-400 font-light" placeholder="Email" />
            </div>
            <div>
              <input type="password" id="password" name="password" required className="w-full px-0 py-3 border-0 border-b border-gray-300 bg-transparent focus:outline-none focus:border-black text-black placeholder-gray-400 font-light" placeholder="Password" />
            </div>
            <button type="submit" className="w-full bg-black text-white py-3 px-4 rounded-lg hover:bg-gray-800 focus:outline-none transition-colors font-light">Sign In</button>
          </form>
        </div>
      </div>
    );
  }

  // Stats
  const stats = {
    totalLeads:
      workshopBookings.length +
      contactSubmissions.length +
      brochureRequests.length +
      exerciseResponses.length +
      assessments.length +
      newsletterSubscribers.length,
    newToday:
      workshopBookings.filter(b => new Date(b.created_at).toDateString() === new Date().toDateString()).length +
      contactSubmissions.filter(c => new Date(c.created_at).toDateString() === new Date().toDateString()).length,
    conversionRate: (workshopBookings.filter(b => b.status === 'confirmed').length / Math.max(workshopBookings.length, 1)) * 100,
    activeWorkshops: workshopBookings.filter(b => b.status === 'confirmed' || b.status === 'pending').length,
  };

  // Column builders using schema
  const columnsBySection: Record<AdminSection, Column[] | null> = {
    dashboard: null,
    analytics: null,
    leads: [
      {
        key: 'created_at',
        label: 'Date',
        sortable: true,
        sortValue: (row: any) => new Date(row.created_at).getTime(),
        render: (v: string) => new Date(v).toLocaleDateString('en-GB'),
        alwaysVisible: true,
      },
      { key: 'type', label: 'Type', sortable: true, render: (v: string) => <Badge variant="secondary">{v}</Badge> },
      { key: 'name', label: 'Name', sortable: true },
      { key: 'email', label: 'Email', sortable: true, render: (v: string) => <a className="text-primary hover:underline" href={`mailto:${v}`}>{v}</a> },
      { key: 'company', label: 'Company', sortable: true, render: (v: string) => v || '-' },
      { key: 'source', label: 'Source', sortable: true, render: (v: string) => <Badge variant="outline">{v}</Badge> },
      { key: 'status', label: 'Status', sortable: true, render: (v: string) => <Badge variant={v === 'confirmed' || v === 'active' || v === 'completed' ? 'default' : 'secondary'}>{v}</Badge> },
    ],
    profiles: null,
    contact: [
      { key: 'created_at', label: 'Date', sortable: true, sortValue: (r: any) => new Date(r.created_at).getTime(), render: (v: string) => new Date(v).toLocaleDateString('en-GB'), alwaysVisible: true },
      { key: 'name', label: 'Name', sortable: true },
      { key: 'email', label: 'Email', sortable: true, render: (v: string) => <a className="text-primary hover:underline" href={`mailto:${v}`}>{v}</a> },
      { key: 'company', label: 'Company', sortable: true, render: (v: string) => v || '-' },
      { key: 'phone', label: 'Phone', sortable: true, render: (v: string) => v || '-' },
      { key: 'service', label: 'Service', sortable: true, render: (v: string) => v || '-' },
      { key: 'form_type', label: 'Form', sortable: true, render: (v: string) => <Badge variant="outline">{(v || '').replace('_',' ')}</Badge> },
      { key: 'message', label: 'Message', render: (v: string) => <div className="max-w-xs truncate">{v || '-'}</div> },
    ],
    workshops: [
      { key: 'created_at', label: 'Date', sortable: true, sortValue: (r: any) => new Date(r.created_at).getTime(), render: (v: string) => new Date(v).toLocaleDateString('en-GB'), alwaysVisible: true },
      { key: 'name', label: 'Name', sortable: true, sortValue: (r: any) => (r.first_name || '') + ' ' + (r.last_name || ''), render: (_: any, row: any) => `${row.first_name} ${row.last_name}` },
      { key: 'email', label: 'Email', sortable: true, render: (v: string) => <a className="text-primary hover:underline" href={`mailto:${v}`}>{v}</a> },
      { key: 'company', label: 'Company', sortable: true, render: (v: string) => v || '-' },
      { key: 'workshop_type', label: 'Workshop', sortable: true },
      { key: 'preferred_date', label: 'Pref. Date', sortable: true, sortValue: (r: any) => r.preferred_date ? new Date(r.preferred_date).getTime() : 0, render: (v: string) => v ? new Date(v).toLocaleDateString('en-GB') : '-' },
      { key: 'preferred_time', label: 'Time', sortable: true, render: (v: string) => v || '-' },
      { key: 'language', label: 'Lang', sortable: true, render: (v: string) => <Badge variant="outline">{(v || '').toUpperCase()}</Badge> },
      { key: 'location_preference', label: 'Location', sortable: true, render: (v: string) => v || '-' },
      { key: 'budget_range', label: 'Budget', sortable: true, render: (v: string) => v || '-' },
      { key: 'status', label: 'Status', sortable: true, render: (v: string, row: any) => <Badge variant={v === 'confirmed' ? 'default' : v === 'pending' ? 'secondary' : 'outline'}>{v}</Badge> },
    ],
    brochures: [
      { key: 'created_at', label: 'Date', sortable: true, sortValue: (r: any) => new Date(r.created_at).getTime(), render: (v: string) => new Date(v).toLocaleDateString('en-GB'), alwaysVisible: true },
      { key: 'name', label: 'Name', sortable: true, sortValue: (r: any) => (r.first_name || '') + ' ' + (r.last_name || ''), render: (_: any, row: any) => `${row.first_name} ${row.last_name}` },
      { key: 'email', label: 'Email', sortable: true, render: (v: string) => <a className="text-primary hover:underline" href={`mailto:${v}`}>{v}</a> },
      { key: 'company', label: 'Company', sortable: true, render: (v: string) => v || '-' },
      { key: 'position', label: 'Position', sortable: true, render: (v: string) => v || '-' },
      { key: 'team_size', label: 'Team Size', sortable: true, render: (v: any) => v || '-' },
      { key: 'city', label: 'City', sortable: true, render: (v: string) => v || '-' },
      { key: 'industry', label: 'Industry', sortable: true, render: (v: string) => v || '-' },
      { key: 'specific_interests', label: 'Interests', render: (v: string) => <div className="max-w-xs truncate">{v || '-'}</div> },
    ],
    exercises: [
      { key: 'created_at', label: 'Date', sortable: true, sortValue: (r: any) => new Date(r.created_at).getTime(), render: (v: string) => new Date(v).toLocaleDateString('en-GB'), alwaysVisible: true },
      { key: 'name', label: 'Name', sortable: true, sortValue: (r: any) => (r.first_name || '') + ' ' + (r.last_name || ''), render: (_: any, row: any) => `${row.first_name || ''} ${row.last_name || ''}`.trim() || '-' },
      { key: 'email', label: 'Email', sortable: true, render: (v: string) => v ? <a className="text-primary hover:underline" href={`mailto:${v}`}>{v}</a> : '-' },
      { key: 'exercise_type', label: 'Exercise', sortable: true, render: (v: string) => <Badge variant="outline">{v}</Badge> },
      { key: 'completion_percentage', label: 'Progress', sortable: true, render: (v: number = 0) => (<div className="flex items-center gap-2"><div className="w-16 bg-gray-200 rounded-full h-2"><div className="bg-primary h-2 rounded-full" style={{ width: `${v || 0}%` }} /></div><span className="text-sm">{v || 0}%</span></div>) },
    ],
    assessments: [
      { key: 'created_at', label: 'Date', sortable: true, sortValue: (r: any) => new Date(r.created_at).getTime(), render: (v: string) => new Date(v).toLocaleDateString('en-GB'), alwaysVisible: true },
      { key: 'email', label: 'Email', sortable: true, render: (v: string) => v ? <a className="text-primary hover:underline" href={`mailto:${v}`}>{v}</a> : '-' },
      { key: 'user_session_id', label: 'Session ID', sortable: true, render: (v: string) => v ? <div className="max-w-24 truncate text-xs">{v}</div> : '-' },
      { key: 'completion_status', label: 'Status', sortable: true, render: (v: string) => <Badge variant={v === 'completed' ? 'default' : v === 'in_progress' ? 'secondary' : 'outline'}>{(v || '').replace('_',' ')}</Badge> },
      { key: 'completion_percentage', label: 'Completion', sortable: true, render: (v: number = 0) => <Badge variant={v === 100 ? 'default' : 'secondary'}>{v || 0}%</Badge> },
      { key: 'time_spent_minutes', label: 'Time Spent', sortable: true, render: (v: number) => v ? `${v} min` : '-' },
    ],
    newsletter: [
      { key: 'created_at', label: 'Date', sortable: true, sortValue: (r: any) => new Date(r.created_at).getTime(), render: (v: string) => new Date(v).toLocaleDateString('en-GB'), alwaysVisible: true },
      { key: 'name', label: 'Name', sortable: true, render: (_: any, row: any) => row.first_name && row.last_name ? `${row.first_name} ${row.last_name}` : 'Subscriber' },
      { key: 'email', label: 'Email', sortable: true, render: (v: string) => <a className="text-primary hover:underline" href={`mailto:${v}`}>{v}</a> },
      { key: 'company', label: 'Company', sortable: true, render: (v: string) => v || '-' },
      { key: 'subscription_source', label: 'Source', sortable: true, render: (v: string) => <Badge variant="outline">{v || 'Unknown'}</Badge> },
      { key: 'is_active', label: 'Status', sortable: true, render: (v: boolean) => <Badge variant={v ? 'default' : 'secondary'}>{v ? 'Active' : 'Inactive'}</Badge> },
      { key: 'preferences', label: 'Preferences', render: (v: any) => v ? <div className="max-w-32 truncate text-xs">{JSON.stringify(v).substring(0, 20)}…</div> : '-' },
    ],
  };

  const renderContent = () => {
    switch (currentSection) {
      case 'analytics':
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-light text-black tracking-wide">Analytics Dashboard</h2>
                <p className="text-gray-500 font-light">Comprehensive analytics and tracking insights</p>
              </div>
              <Button className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4" />
                Open Analytics
              </Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                    <BarChart3 className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Page Views</p>
                    <p className="text-2xl font-light text-black">1,247</p>
                  </div>
                </div>
              </Card>
              <Card className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                    <Users className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Unique Visitors</p>
                    <p className="text-2xl font-light text-black">892</p>
                  </div>
                </div>
              </Card>
              <Card className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-orange-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Conversions</p>
                    <p className="text-2xl font-light text-black">147</p>
                  </div>
                </div>
              </Card>
              <Card className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                    <Activity className="w-6 h-6 text-purple-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Engagement</p>
                    <p className="text-2xl font-light text-black">68%</p>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        );
      case 'dashboard':
        return (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="p-6 hover:shadow-md transition-shadow">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                    <Users className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Total Leads</p>
                    <h2 className="text-2xl font-semibold text-gray-900">{stats.totalLeads}</h2>
                  </div>
                </div>
              </Card>
              <Card className="p-6 hover:shadow-md transition-shadow">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">New Today</p>
                    <h2 className="text-2xl font-semibold text-gray-900">{stats.newToday}</h2>
                  </div>
                </div>
              </Card>
              <Card className="p-6 hover:shadow-md transition-shadow">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                    <BarChart3 className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Conversion Rate</p>
                    <h2 className="text-2xl font-semibold text-gray-900">{stats.conversionRate.toFixed(1)}%</h2>
                  </div>
                </div>
              </Card>
              <Card className="p-6 hover:shadow-md transition-shadow">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                    <Activity className="w-6 h-6 text-orange-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Active Workshops</p>
                    <h2 className="text-2xl font-semibold text-gray-900">{stats.activeWorkshops}</h2>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        );
      case 'workshops':
      case 'contact':
      case 'brochures':
      case 'exercises':
      case 'assessments':
      case 'newsletter': {
        const columns = columnsBySection[currentSection] as Column[];
        const dataset =
          currentSection === 'workshops' ? workshopBookings :
          currentSection === 'contact' ? contactSubmissions :
          currentSection === 'brochures' ? brochureRequests :
          currentSection === 'exercises' ? exerciseResponses :
          currentSection === 'assessments' ? assessments :
          newsletterSubscribers;
        const loading =
          currentSection === 'workshops' ? workshopBookingsLoading :
          currentSection === 'contact' ? contactSubmissionsLoading :
          currentSection === 'brochures' ? brochureRequestsLoading :
          currentSection === 'exercises' ? exerciseResponsesLoading :
          currentSection === 'assessments' ? assessmentsLoading :
          newsletterSubscribersLoading;

        return (
          <ResponsiveTable
            title={
              currentSection === 'workshops' ? 'Workshop Bookings' :
              currentSection === 'contact' ? 'Contact Submissions' :
              currentSection === 'brochures' ? 'Brochure Requests' :
              currentSection === 'exercises' ? 'Exercise Responses' :
              currentSection === 'assessments' ? 'Assessments' :
              'Newsletter Subscribers'
            }
            subtitle={
              currentSection === 'workshops' ? 'Manage workshop registrations and track attendance' :
              currentSection === 'contact' ? 'Manage and respond to customer inquiries' :
              currentSection === 'brochures' ? 'Manage brochure download requests' :
              currentSection === 'exercises' ? 'Manage exercise submissions and track progress' :
              currentSection === 'assessments' ? 'Manage assessment completions and results' :
              'Manage newsletter subscribers and subscriptions'
            }
            columns={columns}
            data={dataset}
            loading={loading}
            storageKey={`rt:${currentSection}`}
            onViewDetails={(item) => { setSelectedEntry(item); setDetailsDialogOpen(true); }}
            onDeleteItem={(item) => console.log('Delete item', item)}
            onDeleteSelected={(items) => console.log('Delete selected', items)}
            onRefresh={() => loadAll()}
            selectedItems={selectedItems}
            onSelectItem={handleSelectItem}
            onSelectAll={handleSelectAll}
            selectAll={selectAll}
            initialPageSize={20}
          />
        );
      }
      case 'leads': {
        const unified = [
          ...workshopBookings.map(b => ({
            id: `workshop-${b.id}`,
            type: 'Workshop Booking',
            name: `${b.first_name} ${b.last_name}`,
            email: b.email,
            company: b.company,
            created_at: b.created_at,
            status: b.status,
            source: 'Workshop',
          })),
          ...contactSubmissions.map(c => ({
            id: `contact-${c.id}`,
            type: 'Contact Submission',
            name: c.name || '',
            email: c.email,
            company: c.company,
            created_at: c.created_at,
            status: 'submitted',
            source: 'Contact Form',
          })),
          ...brochureRequests.map(r => ({
            id: `brochure-${r.id}`,
            type: 'Brochure Request',
            name: `${r.first_name} ${r.last_name}`,
            email: r.email,
            company: r.company,
            created_at: r.created_at,
            status: 'requested',
            source: 'Brochure',
          })),
          ...exerciseResponses.map(e => ({
            id: `exercise-${e.id}`,
            type: 'Exercise Response',
            name: `${e.first_name || ''} ${e.last_name || ''}`.trim(),
            email: e.email,
            company: e.company,
            created_at: e.created_at,
            status: e.completion_status || 'in_progress',
            source: 'Exercise',
          })),
          ...assessments.map(a => ({
            id: `assessment-${a.id}`,
            type: 'Assessment',
            name: `${a.first_name || ''} ${a.last_name || ''}`.trim(),
            email: a.email,
            company: a.company,
            created_at: a.created_at,
            status: a.completion_status || 'completed',
            source: 'Assessment',
          })),
          ...newsletterSubscribers.map(n => ({
            id: `newsletter-${n.id}`,
            type: 'Newsletter Subscription',
            name: `${n.first_name || ''} ${n.last_name || ''}`.trim() || 'Subscriber',
            email: n.email,
            company: n.company,
            created_at: n.created_at,
            status: n.is_active ? 'active' : 'inactive',
            source: 'Newsletter',
          })),
        ].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

        return (
          <ResponsiveTable
            title="All Leads"
            subtitle="Comprehensive view of all lead data across all sources"
            columns={columnsBySection.leads as Column[]}
            data={unified}
            loading={
              workshopBookingsLoading ||
              contactSubmissionsLoading ||
              brochureRequestsLoading ||
              exerciseResponsesLoading ||
              assessmentsLoading ||
              newsletterSubscribersLoading
            }
            storageKey="rt:leads"
            onViewDetails={(item) => { setSelectedEntry(item); setDetailsDialogOpen(true); }}
            onRefresh={() => loadAll()}
            selectedItems={selectedItems}
            onSelectItem={handleSelectItem}
            onSelectAll={handleSelectAll}
            selectAll={selectAll}
            initialPageSize={20}
          />
        );
      }
      default:
        return null;
    }
  };

  const pageContent = (<div>{renderContent()}</div>);

  return (
    <>
      <AdminLayout
        currentSection={currentSection}
        onSectionChange={setCurrentSection}
        onLogout={logout}
        userEmail={me!.email}
        stats={stats}
        children={pageContent}
      />

      {/* Details Dialog */}
      <Dialog open={detailsDialogOpen} onOpenChange={setDetailsDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Entry Details</DialogTitle>
            <DialogDescription>Complete information for this entry</DialogDescription>
          </DialogHeader>
          {selectedEntry && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500 font-medium">Name</p>
                  <p>{selectedEntry.first_name || ''} {selectedEntry.last_name || selectedEntry.name || ''}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 font-medium">Email</p>
                  <p>{selectedEntry.email}</p>
                </div>
              </div>

              {selectedEntry.company && (
                <div>
                  <p className="text-sm text-gray-500 font-medium">Company</p>
                  <p>{selectedEntry.company}</p>
                </div>
              )}

              {selectedEntry.message && (
                <div>
                  <p className="text-sm text-gray-500 font-medium">Message</p>
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p>{selectedEntry.message}</p>
                  </div>
                </div>
              )}

              {selectedEntry.workshop_type && (
                <div>
                  <p className="text-sm text-gray-500 font-medium">Workshop Type</p>
                  <p>{selectedEntry.workshop_type}</p>
                </div>
              )}

              <div>
                <p className="text-sm text-gray-500 font-medium">Created</p>
                <p>{new Date(selectedEntry.created_at).toLocaleDateString('en-GB', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit',
                })}</p>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setDetailsDialogOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
